@echo off
rem RUNALL.BAT (driver .637): the bring-up tests in order, their logs gathered in the LOGS folder.
rem Run it from the tools folder (double-click it). It carries on in a minimized window: an open DOS window's blinking cursor
rem was read back by the 2D tests as 7 wrong pixels (.580). Do not move the mouse while a test runs.
rem VX2FLIP ends with a message box: press Enter there. Notepad opens LOGS\RUNALL.TXT when all ten are done.
rem A test that hangs: LOGS\RUNALL.TXT names the last one started; restart, and send what LOGS holds.
if "%1"=="GO" goto go
start /m RUNALL.BAT GO
goto end
:go
if not exist LOGS\NUL md LOGS
echo started > LOGS\RUNALL.TXT

echo VXREG started >> LOGS\RUNALL.TXT
if exist VXREG.LOG del VXREG.LOG
start /w VXREG.EXE
if exist VXREG.LOG copy VXREG.LOG LOGS > NUL

echo VX2GDI started >> LOGS\RUNALL.TXT
if exist VX2GDI.TXT del VX2GDI.TXT
if exist VX2GDI.RES del VX2GDI.RES
start /w VX2GDI.EXE
if exist VX2GDI.TXT copy VX2GDI.TXT LOGS > NUL
if exist VX2GDI.RES copy VX2GDI.RES LOGS > NUL

echo VXGTUNE started >> LOGS\RUNALL.TXT
if exist VXGTUNE.TXT del VXGTUNE.TXT
if exist VXGTUNE.RES del VXGTUNE.RES
start /w VXGTUNE.EXE
if exist VXGTUNE.TXT copy VXGTUNE.TXT LOGS > NUL
if exist VXGTUNE.RES copy VXGTUNE.RES LOGS > NUL

echo VX2FLIP started >> LOGS\RUNALL.TXT
if exist VX2FLIP.TXT del VX2FLIP.TXT
start /w VX2FLIP.EXE
if exist VX2FLIP.TXT copy VX2FLIP.TXT LOGS > NUL

echo VXFLIPF started >> LOGS\RUNALL.TXT
if exist VXFLIPF.LOG del VXFLIPF.LOG
start /w VXFLIPF.EXE
if exist VXFLIPF.LOG copy VXFLIPF.LOG LOGS > NUL

echo VXDX7 started >> LOGS\RUNALL.TXT
if exist VXDX7.TXT del VXDX7.TXT
start /w VXDX7.EXE
if exist VXDX7.TXT copy VXDX7.TXT LOGS > NUL

echo VXGL started >> LOGS\RUNALL.TXT
if exist VXGL.TXT del VXGL.TXT
start /w VXGL.EXE
if exist VXGL.TXT copy VXGL.TXT LOGS > NUL

echo VXSTEN started >> LOGS\RUNALL.TXT
if exist VXSTEN.TXT del VXSTEN.TXT
start /w VXSTEN.EXE
if exist VXSTEN.TXT copy VXSTEN.TXT LOGS > NUL

echo VXTEX started >> LOGS\RUNALL.TXT
if exist VXTEX.TXT del VXTEX.TXT
start /w VXTEX.EXE
if exist VXTEX.TXT copy VXTEX.TXT LOGS > NUL

echo VXALT started >> LOGS\RUNALL.TXT
if exist VXALT.LOG del VXALT.LOG
start /w VXALT.EXE
if exist VXALT.LOG copy VXALT.LOG LOGS > NUL

echo finished >> LOGS\RUNALL.TXT
start notepad LOGS\RUNALL.TXT
:end
