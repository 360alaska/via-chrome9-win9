@echo off
rem Driver .793: 3DMark 2001's Environment Bump Mapping test watched by VXD3DMON (the alien missing on all three chips in T736).
rem 1. This starts VXD3DMON HOLD (it follows every program that draws until you press a key in its window, 15 minutes at most).
rem 2. Start 3DMark, Tests: select only Environment Bump Mapping, run it. 3. Close 3DMark, press a key in the VXD3DMON window.
rem 4. Send EMBMMON.TXT and C:\VXD3D.REC (8 frames recorded 12 s into the test, for replay on the host).
if not exist VXD3DMON.EXE goto nofiles
if exist VXD3DMON.TXT del VXD3DMON.TXT
if exist C:\VXD3D.REC del C:\VXD3D.REC
start /w VXD3DMON.EXE 900 HOLD REC=8 RECAT=D12
if exist VXD3DMON.TXT copy VXD3DMON.TXT EMBMMON.TXT >nul
echo Done. Send EMBMMON.TXT and C:\VXD3D.REC.
goto end
:nofiles
echo VXD3DMON.EXE must be in the current folder.
:end
pause
