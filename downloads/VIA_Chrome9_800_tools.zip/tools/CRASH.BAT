@echo off
rem Driver .793: VXCRASH, run on its own (not part of QUICK.BAT or ALL.BAT): it crashes full-screen programs on purpose.
rem A full-screen Direct3D 7 program is crashed seven ways (between frames, mid-scene, inside a driver call, as a process the driver never
rem attached in, after taking a 3D give-up (the engine must come back), with the software device, with DirectDraw acceleration off); after each, three programs must still go full screen and
rem draw, and a Direct3D 8 device must be made. 2-3 minutes; the screen changes mode many times. Close other programs first.
rem If it stops for over a minute: restart, and send VXCRASH.LOG anyway (each step is written as it happens).
rem Run it again after the restart: it puts back DirectDraw's EmulationOnly value if a run never finished.
if not exist VXCRASH.EXE goto nofiles
if not exist %windir%\SYSTEM\D3D8.DLL goto nodx
start /w VXCRASH.EXE
echo Done. Send VXCRASH.LOG.
goto end
:nofiles
echo VXCRASH.EXE must be in the current folder.
goto end
:nodx
echo DirectX 8.1 or later is not installed (no D3D8.DLL in the SYSTEM folder).
:end
pause
