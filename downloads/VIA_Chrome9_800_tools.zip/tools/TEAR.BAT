@echo off
rem Driver .793: the tear flip (a no-vsync flip shown from the next scan line), about a minute.
rem 120 frames of 20 ms each with ACCEL_FLIP_TEAR 0, 1 (and 2 when a second monitor mirrors through IGA2).
rem Watch the screen: white with a red bar across the middle. Answer each question. Send VXNOSYNC.LOG.
if not exist VXNOSYNC.EXE goto nofiles
start /w VXNOSYNC.EXE TEAR
echo Done. Send VXNOSYNC.LOG.
goto end
:nofiles
echo VXNOSYNC.EXE must be in the current folder.
:end
pause
