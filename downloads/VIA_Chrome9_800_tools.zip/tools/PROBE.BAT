@echo off
rem Driver .793: VXCLIP, the guard band / clipping engine / clip-to-screen probe and a read-only dump of the engine registers at
rem 0xE00-0xEFF (the DMA engine question). Run it AFTER ALL.BAT, in its own boot if ALL.BAT is not done: a form can hang the engine
rem (the lab resets it and goes on, but a hang may end the boot). The desktop must be 800 x 600 or smaller at 32-bit, or 1024 x 768 at
rem 16-bit (the lab uses video memory from 2 MB). Send VXCLIP.LOG.
if not exist VXCLIP.EXE goto nofiles
if exist VXCLIP.LOG del VXCLIP.LOG
echo VXCLIP: about 15 seconds; the screen is not touched.
VXCLIP.EXE
echo Done. Send VXCLIP.LOG.
goto end
:nofiles
echo VXCLIP.EXE must be in the current folder.
:end
pause
