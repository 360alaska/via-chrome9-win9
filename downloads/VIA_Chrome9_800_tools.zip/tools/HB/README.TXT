HarborBench 1.6
===============

Extract the ZIP to a writable folder. Double-click HarborBench.exe for the
INI-selected display mode, or RunFullscreen.bat to force fullscreen. It reads
HarborBench.ini next to the executable. The same window stays open through
all scenes, resolutions and graphics APIs. Press Esc to stop and view
partial results, or close the window to stop and exit. After a run, scroll
through the summary in the results window. Close it when you are done.
Each launch replaces results.txt and frames.csv. Keep copies for driver A/B
comparisons.

This 32-bit x86 build targets Windows 98 and Windows XP. For D3D8 install
DirectX 8.1 or later and an active graphics driver with a Direct3D HAL.
For OpenGL use a driver with an OpenGL ICD for hardware-accelerated results.
Check the renderer in results.txt. Microsoft's GDI Generic OpenGL renderer
can run the scene in software.

Configuration
-------------

Edit [Benchmark] in Notepad. Save the INI as ANSI text.

    API=both
    VertexProcessing=both
    Scenes=downtown,drive,pedestrians,rain,pursuit,industrial,arena
    Resolutions=640x480,800x600,1024x768
    Mode=full

API accepts d3d8, opengl, or both. With API=both the benchmark runs Direct3D
first and then OpenGL for each scene and resolution. Industrial and Arena
start with OpenGL, then run Direct3D. VertexProcessing accepts
software, hardware, or both. With both, Direct3D runs software first, then
hardware if advertised. Hardware selects the driver's advertised T&L path.
An unsupported hardware pass is logged as skipped with no software fallback.
This option has no effect on OpenGL. Set FPUPreserve=1 to enable the optional
D3D8 creation flag. The default is 0.

Scenes accepts the names above and the diagnostic names below in any order.
Run HarborBench.exe /scene=arena to override the scene list for a single case.
Use /scene=sweeps for diagnostics only or /scene=all for all scenes and sweeps.
These switches can be combined with /fullscreen, /windowed or /ram.
Resolutions accepts up to 12 WIDTHxHEIGHT entries, from 320x200 through
1920x1200. The default is a 640x480 window. The display and driver must
support the chosen sizes. For fullscreen use Fullscreen=1 and ColorBits=16
or ColorBits=32. Windowed color depth comes from the desktop/pixel format.
RunFullscreen.bat passes /fullscreen to the program. /windowed forces a
window if the INI selects fullscreen. Set ColorBits=16 if your adapter only
offers a given fullscreen resolution at 16-bit color. The results show the
requested display mode. If D3D8 loses its device, return to the window.
HarborBench resets the device, recreates its rendering resources, and
restarts only the interrupted pass from warm-up. The interrupted samples
and recovery time are excluded. Press Esc to cancel after returning.
VSync=0 requests immediate presentation where supported. Check the presentation
mode in the results. WindowScale sets the D3D8 window size as a percentage
of the render resolution (25-200). At 100 it uses the normal presentation
path. Other values use a COPY swap chain and stretched Present. OpenGL and
fullscreen use the listed render size directly.

Set RAMRun=1 in [Benchmark] or pass /ram to turn on RAM mode. For example,
run HarborBench.exe /fullscreen /ram to use both options. RAM mode reads
ahead the benchmark and selected graphics runtimes before timing. Windows
XP can lock some of the benchmark's executable pages when its quota allows.
Windows 98 uses read-ahead. Both result files are buffered until the run
ends, and both are saved on normal completion or cancellation. Large batches
use more RAM for the CSV. The benchmark's meshes and textures are generated
in memory, including the Drive scene's measured texture uploads.

RAM mode reduces benchmark-related disk activity. Windows can still page
unlocked memory or load driver components, and other programs can use the
disk. Keep WarmupFrames above zero to exercise the rendering path before
measurement.

Frames sets measured frames per scene (1-1500), WarmupFrames sets frames before
measurement (0-300), and Repeats runs the same route up to five times per size
and API. The shipped settings use 200 measured frames after 10 warm-up
frames. Pursuit, Industrial, and Arena each complete one camera cycle in
the measured interval. A different scene frame count rescales that path.
For a short check on a slow driver use Frames=25 and WarmupFrames=2.
Full mode runs each simulation tick and renders its result. Simulation mode
times only the deterministic traffic and pedestrian simulation. Replay mode
generates simulation snapshots in advance, then draws the same camera and
world states. Replay mode uses more RAM and works with either API.

Each scene section has its own Vehicles (0-192), Pedestrians (0-256),
DrawDistance (50-230), and Seed (0-999999). RainParticles (0-1200) applies
to Rain, Industrial, and Arena. For Industrial and Arena, Pedestrians sets
bot count and RainParticles sets the effect density. Counts are the total
populations.
Visible counts vary with the camera and draw distance.

For the pursuit stress test alone, set Scenes=pursuit. The shipped 22-tick
escalation reaches the final police wave during the 200-frame measurement.
Any scene can override the global frame count with Frames in its own INI
section. PoliceLimit
(0-64) caps the active police fleet. EscalationTicks (8-300) sets the delay
between waves. The first wave starts with up to four police cars, and each
wave adds up to six cars and shortens the interval between launches.
ExplosionParticles (0-300) controls the amount of smoke per blast, with
additional additive fire sprites. The fixed tick is 1/25 of a simulation
second. One tick is simulated per rendered frame.

Workload
--------

Downtown faces a busy junction. Drive moves down a city avenue and replaces
facade textures at district boundaries. Pedestrians moves and pans from
sidewalk height. Rain runs the night lighting, headlights, lamps, and rain
particles alongside traffic and walkers. Pursuit follows an original
character firing animated rockets at vehicles while police arrive in waves.
It combines lit characters, wheels and rotating debris with additive fire,
translucent smoke, road flashes, and a moving light on nearby objects.
Direct3D uses a directional flash if positional lighting is unavailable.

Industrial is an original corridor firefight with changing lightmaps,
weapon flashes, decals, and cutout grates. Arena is an original open-sky
match with curved arches, jump pads, moving material layers, and heavy
particle overdraw. Both render weapon trails, explosions, stylized blood,
scorch decals, a brief hit overlay, and a first-person weapon in a narrowed
depth range. The lightmap combines on unit 1 with multitexture or draws
as a multiply pass. Industrial updates a small region per frame
(glTexSubImage2D in OpenGL). OpenGL uses compiled arrays where advertised.

Diagnostics
-----------

  draw100, draw500, draw1000, draw2000
    Same 3,200 triangles and state, across 100, 500, 1,000 or 2,000 draws.

  lights1, lights2, lights4, lights8, specular, spotlights
    Same model workload in D3D8 hardware VP. Point-light count varies.
    specular and spotlights use four lights for comparison with lights4.
    The runs require the advertised caps and skip explicitly if unavailable.

  particles500, particles2000, particles8000
    Fixed sprite counts. D3D8 exposes DISCARD and NOOVERWRITE lock counts.

  stages3
    D3D8 three simultaneous textures with three distinct UV sets. The
    adapter needs at least three blend stages and simultaneous textures.

The city grid, buildings, material textures, three vehicle bodies, wheels,
walkers, and effects are original procedural assets generated in city.c.
Vehicles use following behavior, signal-based speed changes, and proximity
checks. Pedestrians animate articulated limbs and use sidewalks and crossings.
Moving meshes use per-object matrices, normals, and fixed-function lighting.
Both APIs draw the same meshes, actors, and effects. Near buildings, vehicles
and articulated walkers have tessellated meshes. The geometry uses back-face
culling, and static textured meshes use baked vertex colors. Rain submits
batches of up to 128 particles. Direct3D writes those batches into a dynamic
vertex buffer with DISCARD and NOOVERWRITE and draws the HUD with pretransformed
vertices and DrawPrimitiveUP. Direct3D uses a HAL device for both VP modes.
OpenGL uses the fixed-function API and Windows OpenGL 1.1 entry points.

Textures are 256x256 with mip levels on supported drivers. Multitexture=1
requests a second detail stage when available. Use Multitexture=0 if only one
driver supports the second stage and you want identical stage counts. DXT1=1
requests compression for selected opaque textures in Direct3D. OpenGL always
uses RGBA textures. Leave DXT1=0 for a format-matched comparison when the D3D
adapter can use RGBA8.

Results
-------

results.txt contains the driver identifier, scene settings, mean FPS, mean
frame time, median, 95th percentile, and worst frame per run. frames.csv contains
per-frame measurements, the vertex-processing mode, and counters for
dynamic-buffer locks, texture updates, and UP draws. DriverBuild stores a
custom version label. D3D8 also reports the adapter's driver version. Pursuit adds active police, rockets,
detonations, and blended sprite counts. Submission time includes render setup, visibility
selection, draw calls and resource updates. Present time is CPU time spent in
Present or SwapBuffers, which can include synchronization. Resource bytes count
application-side resource data supplied on that frame. Pick identical scene,
resolution, color depth, presentation, and warmup settings for comparisons.

Set CaptureFrame=63 to save a BMP for each selected graphics case at
simulation tick 63 (including warm-up ticks). The program reruns the case
after all timed passes to keep readback and file I/O outside the score.
Direct3D captures require a lockable back buffer. A failed capture is logged
without invalidating a completed timing pass. CaptureFrame=0 disables it.

The game-inspired scenes use original procedural assets and synthetic
workloads. Linux OpenGL tests covered the new scenes with multitexture and
with the two-pass fallback. Native Win98, XP, and VX855 testing is pending.

Building
--------

The ZIP includes the 32-bit executable and C sources. To rebuild, put
i686 MinGW-w64 GCC and binutils on PATH and run build.bat from the extracted
directory on a build PC. The program uses the system msvcrt.dll, OpenGL and
Win32 libraries. It loads d3d8.dll on demand for the D3D8 backend.
