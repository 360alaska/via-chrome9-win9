@echo off
rem Driver .793: VXTIME v3.3: the driver's own mode timing, full screen with five borders (white on the edge,
rem red 8, green 16, yellow 32, cyan 64 pixels in). Every size from 640x480 at 60 Hz and at the higher rates with a VESA standard timing; up to 45 seconds a step.
rem Y = all borders there and steady, N = not, no key = not answered, Esc = stop. A step the driver refuses is not shown.
rem TIME.BAT HI: only the sizes above 1024x768. TIME.BAT 75: that one rate. Send VXTIME.LOG.
if not exist VXTIME.EXE goto nofiles
if not exist VXREG.EXE goto nofiles
if exist VXREG.LOG del VXREG.LOG
start /w VXREG.EXE
find "build: .793" VXREG.LOG >nul
if errorlevel 1 goto wrongbuild
start /w VXTIME.EXE %1
echo Done. Send VXTIME.LOG.
goto end
:wrongbuild
echo The installed driver is not .793: copy this build's files and restart first.
goto end
:nofiles
echo VXTIME.EXE and VXREG.EXE must be in the current folder.
:end
pause
