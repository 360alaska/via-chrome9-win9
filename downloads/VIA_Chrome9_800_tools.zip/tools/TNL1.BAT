@echo off
rem Driver .652: The driver's transform and lighting is ON again, the default from .631 (ACCEL_D3D_TNL deleted).
if not exist TNL1.REG goto nofile
regedit /s TNL1.REG
echo The driver's transform and lighting is ON again, the default from .631 (ACCEL_D3D_TNL deleted).
echo Restart Windows, then ALL.BAT.
goto end
:nofile
echo TNL1.REG must be in the current folder.
:end
pause
