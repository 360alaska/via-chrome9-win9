@echo off
rem Driver .793: the 2D engine's proof (made after every engine reset by the 3D side before GDI uses the engine again), under a minute.
rem 1. VXREG GDITEST: the proof made now; it must pass. 2. VXREG GDITEST OFF: the next proof fails on purpose; then drag a window, open
rem a folder, scroll: the desktop must stay right (drawn in software, slower) until a restart. Send VXGDI.LOG.
if not exist VXREG.EXE goto nofiles
if exist VXGDI.LOG del VXGDI.LOG
start /w VXREG.EXE GDITEST
start /w VXREG.EXE GDITEST OFF
echo The next proof fails on purpose: drag windows, open a folder, scroll. The desktop must stay right (slower).
echo Press a key when done, then restart Windows to turn the 2D engine back on.
pause
start /w VXREG.EXE GDITEST
echo Done. Send VXGDI.LOG.
goto end
:nofiles
echo VXREG.EXE must be in the current folder.
:end
pause
