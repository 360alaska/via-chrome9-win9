@echo off
rem Driver .652: The driver's transform and lighting is OFF (ACCEL_D3D_TNL = 0): Direct3D does it, as before .631.
if not exist TNL0.REG goto nofile
regedit /s TNL0.REG
echo The driver's transform and lighting is OFF (ACCEL_D3D_TNL = 0): Direct3D does it, as before .631.
echo Restart Windows, then ALL.BAT.
goto end
:nofile
echo TNL0.REG must be in the current folder.
:end
pause
