@echo off
rem Driver .793: one boot, about 70 minutes with 3DMark. Every step is written to T793\STEPS.TXT before it starts (the last line is the
rem step that was running if the machine stops); after the main steps VXREG CURSOR writes the cursor's state to T793\VXCUR.LOG.
rem 1. VXTLP: the picture checks (2-3 minutes; 6l, back faces culled, against its own frame drawn with nothing culled). 2. VXTLP GRID (4-5 minutes).
rem 3. Profiles under VXD3DMON: 6K, 6E, 6L, 6I, then HarborBench arena and pursuit (hardware T&L).
rem 4. HarborBench, one launch a scene, Direct3D (software and hardware T&L) and OpenGL (about 25 minutes).
rem 5. VXNOSYNC and CLXP3D T153-T162 (two minutes). 6. 3DMark 2001, the full benchmark. 7. VXNOSYNC and CLXP3D again: after T681's 3DMark
rem the engine drew nothing and the desktop broke; they say whether this build still does it.
rem Install .793 (CHROME9.INF) and restart first. Send the folder T793 and the 3DMark photos.
if not exist VXD3DMON.EXE goto nofiles
if not exist VXREG.EXE goto nofiles
if not exist VXTLP.EXE goto nofiles
if not exist CLXP3D.EXE goto nofiles
if not exist VXNOSYNC.EXE goto nofiles
if not exist VXREUSE.EXE goto nofiles
if not exist VXRHW.EXE goto nofiles
if not exist VXDX7.EXE goto nofiles
if not exist VXCLIP.EXE goto nofiles
if not exist FEAT0.REG goto nofiles
if not exist HB\HarborBench.exe goto nofiles
if not exist HB\HarborBench.ini goto nofiles
if not exist HB\HB_HW.INI goto nofiles
if not exist ALLON.REG goto nofiles
if not exist %windir%\SYSTEM\D3D8.DLL goto nodx
start /w VXREG.EXE
find "build: .793" VXREG.LOG >nul
if errorlevel 1 goto wrongbuild
if not exist T793\nul md T793
if exist T793\STEPS.TXT del T793\STEPS.TXT
regedit /s ALLON.REG
if exist VXCUR.LOG del VXCUR.LOG
start /w VXREG.EXE CURSOR start
if exist VXT?_?.BMP del VXT?_?.BMP
if exist VXT??_?.BMP del VXT??_?.BMP
if exist VXTL7*.BMP del VXTL7*.BMP
if exist VXTL1?A.BMP del VXTL1?A.BMP
if exist VXTL1?B.BMP del VXTL1?B.BMP
if exist VXTLC_?.BMP del VXTLC_?.BMP
if exist VXTLF??.BMP del VXTLF??.BMP
if exist 6M*.BMP del 6M*.BMP
if exist 6P*.BMP del 6P*.BMP
if exist 6N*.BMP del 6N*.BMP
if exist 6Q*.BMP del 6Q*.BMP
if exist 6W*.BMP del 6W*.BMP
echo 0. The guard band and the tear flip are on for every chip in this build. If this board misbehaves in any step, run FEAT0.REG
echo    (the tear flip off), restart, and run ALL.BAT again; send both result folders.
echo 0 VXCLIP>> T793\STEPS.TXT
echo 0a. VXCLIP: the engine clipping probe, about 15 seconds; the screen is not touched.
if exist VXCLIP.LOG del VXCLIP.LOG
start /w VXCLIP.EXE
if exist VXCLIP.LOG copy VXCLIP.LOG T793\VXCLIP.LOG >nul
if exist VXCLIP.LOG del VXCLIP.LOG
echo 1 VXTLP>> T793\STEPS.TXT
echo 1. VXTLP: one window, 2-3 minutes; wait for it to close.
start /w VXTLP.EXE
copy VXTLP.LOG T793\VXTLP.LOG >nul
del VXTLP.LOG
start /w VXREG.EXE CURSOR after-VXTLP
if exist VXTL7*.BMP copy VXTL7*.BMP T793 >nul
if exist VXTL7*.BMP del VXTL7*.BMP
if exist VXTL1?A.BMP copy VXTL1?A.BMP T793 >nul
if exist VXTL1?A.BMP del VXTL1?A.BMP
if exist VXTL1?B.BMP copy VXTL1?B.BMP T793 >nul
if exist VXTL1?B.BMP del VXTL1?B.BMP
if exist VXT?_?.BMP copy VXT?_?.BMP T793 >nul
if exist VXT?_?.BMP del VXT?_?.BMP
if exist VXT??_?.BMP copy VXT??_?.BMP T793 >nul
if exist VXT??_?.BMP del VXT??_?.BMP
if exist VXTLC_?.BMP copy VXTLC_?.BMP T793 >nul
if exist VXTLC_?.BMP del VXTLC_?.BMP
if exist VXTLF??.BMP copy VXTLF??.BMP T793 >nul
if exist VXTLF??.BMP del VXTLF??.BMP
if exist 6M*.BMP copy 6M*.BMP T793 >nul
if exist 6M*.BMP del 6M*.BMP
if exist 6P*.BMP copy 6P*.BMP T793 >nul
if exist 6P*.BMP del 6P*.BMP
if exist 6N*.BMP copy 6N*.BMP T793 >nul
if exist 6N*.BMP del 6N*.BMP
if exist 6Q*.BMP copy 6Q*.BMP T793 >nul
if exist 6Q*.BMP del 6Q*.BMP
if exist 6W*.BMP copy 6W*.BMP T793 >nul
if exist 6W*.BMP del 6W*.BMP
echo.
echo 2 GRID>> T793\STEPS.TXT
echo 2. VXTLP GRID: 4-5 minutes; leave the machine alone until the window closes.
start /w VXTLP.EXE GRID
copy VXTLP.LOG T793\GRID.LOG >nul
del VXTLP.LOG
if exist VX?_??.CSV copy VX?_??.CSV T793 >nul
if exist VX?_??.CSV del VX?_??.CSV
if exist VXT?_?.BMP copy VXT?_?.BMP T793 >nul
if exist VXT?_?.BMP del VXT?_?.BMP
if exist VXT??_?.BMP copy VXT??_?.BMP T793 >nul
if exist VXT??_?.BMP del VXT??_?.BMP
if exist VXTLC_?.BMP copy VXTLC_?.BMP T793 >nul
if exist VXTLC_?.BMP del VXTLC_?.BMP
start /w VXREG.EXE CURSOR after-GRID
echo.
echo 2c GRID VP>> T793\STEPS.TXT
echo 2c. VXTLP GRID VP: every GRID scene through a viewport at (40, 40), both devices (the guard band across a clip edge that is not 0), about 5 minutes.
start /w VXTLP.EXE GRID VP
copy VXTLP.LOG T793\GRIDVP.LOG >nul
del VXTLP.LOG
if exist VX?_??.CSV del VX?_??.CSV
if exist VXT?_?.BMP copy VXT?_?.BMP T793 >nul
if exist VXT?_?.BMP del VXT?_?.BMP
if exist VXT??_?.BMP copy VXT??_?.BMP T793 >nul
if exist VXT??_?.BMP del VXT??_?.BMP
if exist VXTLC_?.BMP copy VXTLC_?.BMP T793 >nul
if exist VXTLC_?.BMP del VXTLC_?.BMP
echo.
echo 3. Profiles: VXD3DMON starts each program and closes when it ends; about 20 minutes.
echo 3 profile GRID 6K>> T793\STEPS.TXT
start /w VXD3DMON.EXE 120 RUN VXTLP.EXE GRID HW 6K
copy VXD3DMON.TXT T793\PROF_6K.TXT >nul
del VXD3DMON.TXT
copy VXTLP.LOG T793\PROF_6K.LOG >nul
del VXTLP.LOG
if exist VX?_??.CSV del VX?_??.CSV
if exist VXT?_?.BMP del VXT?_?.BMP
if exist VXT??_?.BMP del VXT??_?.BMP
if exist VXTLC_?.BMP del VXTLC_?.BMP
echo 3 profile GRID 6E>> T793\STEPS.TXT
start /w VXD3DMON.EXE 90 RUN VXTLP.EXE GRID HW 6E
copy VXD3DMON.TXT T793\PROF_HW.TXT >nul
del VXD3DMON.TXT
copy VXTLP.LOG T793\PROF_HW.LOG >nul
del VXTLP.LOG
if exist VX?_??.CSV del VX?_??.CSV
if exist VXT?_?.BMP del VXT?_?.BMP
if exist VXT??_?.BMP del VXT??_?.BMP
if exist VXTLC_?.BMP del VXTLC_?.BMP
echo 3 profile GRID 6L>> T793\STEPS.TXT
start /w VXD3DMON.EXE 120 RUN VXTLP.EXE GRID HW 6L
copy VXD3DMON.TXT T793\PROF_6L.TXT >nul
del VXD3DMON.TXT
copy VXTLP.LOG T793\PROF_6L.LOG >nul
del VXTLP.LOG
if exist VX?_??.CSV del VX?_??.CSV
if exist VXT?_?.BMP del VXT?_?.BMP
if exist VXT??_?.BMP del VXT??_?.BMP
if exist VXTLC_?.BMP del VXTLC_?.BMP
echo 3 profile GRID 6I>> T793\STEPS.TXT
start /w VXD3DMON.EXE 90 RUN VXTLP.EXE GRID HW 6I
copy VXD3DMON.TXT T793\PROF_6I.TXT >nul
del VXD3DMON.TXT
copy VXTLP.LOG T793\PROF_6I.LOG >nul
del VXTLP.LOG
if exist VX?_??.CSV del VX?_??.CSV
if exist VXT?_?.BMP del VXT?_?.BMP
if exist VXT??_?.BMP del VXT??_?.BMP
if exist VXTLC_?.BMP del VXTLC_?.BMP
copy HB\HarborBench.ini HB\HB_MAIN.INI >nul
copy HB\HB_HW.INI HB\HarborBench.ini >nul
echo 3 profile HarborBench arena>> T793\STEPS.TXT
if exist HB\results.txt del HB\results.txt
cd HB
start /w ..\VXD3DMON.EXE 120 RUN HarborBench.exe /fullscreen /ram /scene=arena
cd ..
if exist HB\VXD3DMON.TXT copy HB\VXD3DMON.TXT T793\PROF_ARE.TXT >nul
if exist HB\VXD3DMON.TXT del HB\VXD3DMON.TXT
if exist HB\results.txt copy HB\results.txt T793\HBP_ARE.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo 3 profile HarborBench pursuit>> T793\STEPS.TXT
if exist HB\results.txt del HB\results.txt
cd HB
start /w ..\VXD3DMON.EXE 120 RUN HarborBench.exe /fullscreen /ram /scene=pursuit
cd ..
if exist HB\VXD3DMON.TXT copy HB\VXD3DMON.TXT T793\PROF_PUR.TXT >nul
if exist HB\VXD3DMON.TXT del HB\VXD3DMON.TXT
if exist HB\results.txt copy HB\results.txt T793\HBP_PUR.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
copy HB\HB_MAIN.INI HB\HarborBench.ini >nul
del HB\HB_MAIN.INI
start /w VXREG.EXE CURSOR after-profiles
echo.
echo 4. HarborBench, one scene a launch, Direct3D (software and hardware T&L) and OpenGL: about 25 minutes; leave the machine alone.
echo HarborBench downtown>> T793\STEPS.TXT
echo    HarborBench downtown
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=downtown
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_downtown.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench drive>> T793\STEPS.TXT
echo    HarborBench drive
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=drive
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_drive.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench pedestrians>> T793\STEPS.TXT
echo    HarborBench pedestrians
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=pedestrians
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_pedestrians.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench rain>> T793\STEPS.TXT
echo    HarborBench rain
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=rain
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_rain.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench pursuit>> T793\STEPS.TXT
echo    HarborBench pursuit
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=pursuit
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_pursuit.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench industrial>> T793\STEPS.TXT
echo    HarborBench industrial
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=industrial
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_industrial.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench arena>> T793\STEPS.TXT
echo    HarborBench arena
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=arena
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_arena.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench draw100>> T793\STEPS.TXT
echo    HarborBench draw100
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=draw100
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_draw100.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench draw500>> T793\STEPS.TXT
echo    HarborBench draw500
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=draw500
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_draw500.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench draw1000>> T793\STEPS.TXT
echo    HarborBench draw1000
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=draw1000
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_draw1000.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench draw2000>> T793\STEPS.TXT
echo    HarborBench draw2000
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=draw2000
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_draw2000.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench lights1>> T793\STEPS.TXT
echo    HarborBench lights1
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=lights1
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_lights1.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench lights2>> T793\STEPS.TXT
echo    HarborBench lights2
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=lights2
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_lights2.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench lights4>> T793\STEPS.TXT
echo    HarborBench lights4
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=lights4
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_lights4.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench lights8>> T793\STEPS.TXT
echo    HarborBench lights8
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=lights8
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_lights8.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench specular>> T793\STEPS.TXT
echo    HarborBench specular
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=specular
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_specular.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench spotlights>> T793\STEPS.TXT
echo    HarborBench spotlights
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=spotlights
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_spotlights.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench particles500>> T793\STEPS.TXT
echo    HarborBench particles500
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=particles500
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_particles500.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench particles2000>> T793\STEPS.TXT
echo    HarborBench particles2000
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=particles2000
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_particles2000.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench particles8000>> T793\STEPS.TXT
echo    HarborBench particles8000
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=particles8000
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_particles8000.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
echo HarborBench stages3>> T793\STEPS.TXT
echo    HarborBench stages3
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
cd HB
start /w HarborBench.exe /fullscreen /ram /scene=stages3
cd ..
if exist HB\results.txt copy HB\results.txt T793\HB_stages3.TXT >nul
if exist HB\results.txt del HB\results.txt
if exist HB\frames.csv del HB\frames.csv
start /w VXREG.EXE CURSOR after-HarborBench
echo.
echo 5 VXNOSYNC>> T793\STEPS.TXT
echo 5. VXNOSYNC: full screen, about a minute; the screen must stay white in passes 1-5 (it then shows a small window).
if exist VXNOSYNC.LOG del VXNOSYNC.LOG
start /w VXNOSYNC.EXE
if exist VXNOSYNC.LOG copy VXNOSYNC.LOG T793\VXNOSY.LOG >nul
if exist VXNOSYNC.LOG del VXNOSYNC.LOG
start /w VXREG.EXE CURSOR after-VXNOSYNC
echo 5 CLXP3D>> T793\STEPS.TXT
echo    CLXP3D: the bump-mapping cases from T153, under a minute.
if exist CLXP3D1??.BIN del CLXP3D1??.BIN
start /w CLXP3D.EXE from 153 nocapture
copy CLXP3D.TXT T793\CLXP.TXT >nul
del CLXP3D.TXT
if exist CLXP3D1??.BIN copy CLXP3D1??.BIN T793 >nul
if exist CLXP3D1??.BIN del CLXP3D1??.BIN
start /w VXD3DMON.EXE 3
copy VXD3DMON.TXT T793\CLXPMON.TXT >nul
del VXD3DMON.TXT
echo.
echo 5 VXRHW>> T793\STEPS.TXT
echo    VXRHW: rhw 0, NaN and infinite primitives against rhw 1, under a minute (a small window).
if exist VXRHW.LOG del VXRHW.LOG
start /w VXRHW.EXE
if exist VXRHW.LOG copy VXRHW.LOG T793\RHW.LOG >nul
if exist VXRHW.LOG del VXRHW.LOG
if exist VXRHW_?.BMP copy VXRHW_?.BMP T793 >nul
if exist VXRHW_?.BMP del VXRHW_?.BMP
echo 5 VXDX7 --enum>> T793\STEPS.TXT
echo    VXDX7 --enum: the devices and their caps, a few seconds.
if exist VXDX7.TXT del VXDX7.TXT
start /w VXDX7.EXE --enum
if exist VXDX7.TXT copy VXDX7.TXT T793\ENUM.TXT >nul
if exist VXDX7.TXT del VXDX7.TXT
echo 6 3DMark>> T793\STEPS.TXT
echo 6. 3DMark 2001: VXD3DMON watches until 3DMark closes. Start 3DMark now, run the full benchmark (default tests); photograph the results.
echo    When 3DMark is closed, photograph the desktop if it is garbled (do not drag windows), then press a key.
if exist VXD3DMON.TXT del VXD3DMON.TXT
start VXD3DMON.EXE 1500 HOLD
echo When 3DMark is closed, click the VXD3DMON window and press a key there (it watches every program until then),
echo then press a key here.
pause
copy VXD3DMON.TXT T793\3DMMON.TXT >nul
del VXD3DMON.TXT
start /w VXREG.EXE CURSOR after-3DMark
echo.
echo 7 VXNOSYNCA>> T793\STEPS.TXT
echo 7. VXNOSYNC: full screen, about a minute; the screen must stay white in passes 1-5 (it then shows a small window).
if exist VXNOSYNC.LOG del VXNOSYNC.LOG
start /w VXNOSYNC.EXE
if exist VXNOSYNC.LOG copy VXNOSYNC.LOG T793\VXNOSYA.LOG >nul
if exist VXNOSYNC.LOG del VXNOSYNC.LOG
start /w VXREG.EXE CURSOR after-VXNOSYNCA
echo 7 CLXP3DA>> T793\STEPS.TXT
echo    CLXP3D: the bump-mapping cases from T153, under a minute.
if exist CLXP3D1??.BIN del CLXP3D1??.BIN
start /w CLXP3D.EXE from 153 nocapture
copy CLXP3D.TXT T793\CLXPA.TXT >nul
del CLXP3D.TXT
if exist CLXP3D1??.BIN del CLXP3D1??.BIN
start /w VXD3DMON.EXE 3
copy VXD3DMON.TXT T793\CLXPMONA.TXT >nul
del VXD3DMON.TXT
echo.
echo 7b VXREUSE>> T793\STEPS.TXT
echo 7b. VXREUSE: 24 copies of a small Direct3D program one after another, each keeping a file of its own open, under a minute.
if exist VXREUSE.LOG del VXREUSE.LOG
start /w VXREUSE.EXE
if exist VXREUSE.LOG copy VXREUSE.LOG T793\REUSE.LOG >nul
if exist VXREUSE.LOG del VXREUSE.LOG
start /w VXREG.EXE
copy VXREG.LOG T793\REG.LOG >nul
del VXREG.LOG
copy VXCUR.LOG T793\VXCUR.LOG >nul
del VXCUR.LOG
echo done>> T793\STEPS.TXT
echo Done. Send the folder T793 and the photos.
goto end
:wrongbuild
echo The driver that is running is not .793 (see VXREG.LOG). Install CHROME9.INF from this package, restart, and run this again.
goto end
:nofiles
echo VXD3DMON.EXE, VXREG.EXE, VXTLP.EXE, CLXP3D.EXE, VXNOSYNC.EXE, ALLON.REG and the HB folder (HarborBench.exe, HarborBench.ini, HB_HW.INI) must be in the current folder.
:nodx
echo DirectX 8.1 or later is not installed (no D3D8.DLL in the SYSTEM folder): the Direct3D tests and HarborBench would be skipped.
echo Install DirectX 9.0c, restart, and run this again.
goto end
:end
pause
