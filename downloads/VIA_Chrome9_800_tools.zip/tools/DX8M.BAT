@echo off
rem Driver .793: 3DMark 2001 (a DirectX 8 program) with the driver's DirectX 8 interface ON. Run it only after QUICK.BAT's
rem step 10 (VXDX8 with the interface off and on) has passed on this build. The screen changes mode when the interface is switched.
rem 1. This checks the build, switches the interface on, and starts VXHANG (VXHANG.TXT, ten minutes) and VXD3DMON (VXD3DMON.TXT).
rem 2. Start 3DMark 2001 and run the benchmark with its default settings. Photograph the results (or the screen it stops on).
rem 3. Close 3DMark, come back to this window and press a key: the interface is switched off again (it is also off after any restart).
rem Send VXHANG.TXT, VXD3DMON.TXT, VXVB.LOG and the photograph.
if not exist VXHANG.EXE goto nofiles
if not exist VXD3DMON.EXE goto nofiles
if not exist VXREG.EXE goto nofiles
if exist VXREG.LOG del VXREG.LOG
start /w VXREG.EXE
find "build: .793" VXREG.LOG >nul
if errorlevel 1 goto wrongbuild
if exist VXVB.LOG del VXVB.LOG
start /w VXREG.EXE DX8 ON
if exist VXHANG.TXT del VXHANG.TXT
if exist VXD3DMON.TXT del VXD3DMON.TXT
start /min VXHANG.EXE 600
start /min VXD3DMON.EXE 600 HOLD
echo The DirectX 8 interface is ON. Start 3DMark 2001 now and run the benchmark.
echo When it has finished (or stopped) and 3DMark is closed, press a key here to switch the interface off.
pause
start /w VXREG.EXE DX8 OFF
echo The interface is off again. Send VXHANG.TXT, VXD3DMON.TXT, VXVB.LOG and the photograph.
goto end
:wrongbuild
echo The installed driver is not .793: copy this build's files and restart first.
goto end
:nofiles
echo VXHANG.EXE, VXD3DMON.EXE and VXREG.EXE must be in the current folder.
:end
pause
