@echo off
rem Driver .793: 3DMark 2001 with two watchers (E768 and E769 stayed on Game 1's loading screen with hardware T&L).
rem 1. This checks the installed build, then starts VXHANG (writes VXHANG.TXT every two seconds for three minutes) and VXD3DMON (90 s).
rem 2. Start 3DMark 2001 at once and start the benchmark with its default settings (hardware T&L).
rem 3. If the loading screen stays: wait three minutes, then copy VXHANG.TXT and VXD3DMON.TXT from this folder (over the network share).
rem    If Game 1 starts: let it run, photograph the results, send the same two files.
if not exist VXHANG.EXE goto nofiles
if not exist VXD3DMON.EXE goto nofiles
if not exist VXREG.EXE goto nofiles
if exist VXREG.LOG del VXREG.LOG
start /w VXREG.EXE
find "build: .793" VXREG.LOG >nul
if errorlevel 1 goto wrongbuild
if exist VXHANG.TXT del VXHANG.TXT
if exist VXD3DMON.TXT del VXD3DMON.TXT
start /min VXHANG.EXE 180
start /min VXD3DMON.EXE 90 HOLD
echo Start 3DMark 2001 now.
goto end
:wrongbuild
echo The installed driver is not .793: install this package (CHROME9.INF) and restart first.
goto end
:nofiles
echo VXHANG.EXE, VXD3DMON.EXE and VXREG.EXE must be in the current folder.
:end
pause
