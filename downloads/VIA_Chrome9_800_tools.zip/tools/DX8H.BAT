@echo off
rem Driver .793: the DirectX 8 interface, with the texture formats (3DMark 2001 on E791 with the interface on: textures wrong at a
rem distance, some wholly wrong). 1. VXDX8 TEX with the interface OFF (the reference): VXDX8T7.LOG. 2. The interface ON, VXHANG
rem started, VXDX8 TEX again: VXDX8T8.LOG. 3. VXDX8 whole: VXDX8.LOG. Each window closes by itself; about two minutes in all.
rem Send VXDX8T7.LOG, VXDX8T8.LOG, VXDX8.LOG and VXHANG.TXT. The interface is off again at the end (and after any restart).
if not exist VXHANG.EXE goto nofiles
if not exist VXDX8.EXE goto nofiles
if not exist VXREG.EXE goto nofiles
if exist VXREG.LOG del VXREG.LOG
start /w VXREG.EXE
find "build: .793" VXREG.LOG >nul
if errorlevel 1 goto wrongbuild
if exist VXVB.LOG del VXVB.LOG
if exist VXHANG.TXT del VXHANG.TXT
if exist VXDX8.LOG del VXDX8.LOG
if exist VXDX8T7.LOG del VXDX8T7.LOG
if exist VXDX8T8.LOG del VXDX8T8.LOG
start /w VXREG.EXE DX8 OFF
start /w VXDX8.EXE TEX
copy VXDX8.LOG VXDX8T7.LOG >nul
start /w VXREG.EXE DX8 ON
start /min VXHANG.EXE 180
start /w VXDX8.EXE TEX
copy VXDX8.LOG VXDX8T8.LOG >nul
start /w VXDX8.EXE
start /w VXREG.EXE DX8 OFF
echo Done: the interface is off again. Send VXDX8T7.LOG, VXDX8T8.LOG, VXDX8.LOG and VXHANG.TXT.
goto end
:wrongbuild
echo The installed driver is not .793: copy this build's files and restart first.
goto end
:nofiles
echo VXHANG.EXE, VXDX8.EXE and VXREG.EXE must be in the current folder.
:end
pause
