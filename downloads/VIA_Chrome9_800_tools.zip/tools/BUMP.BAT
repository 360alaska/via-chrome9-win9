@echo off
rem Driver .793: the bump-mapping check alone, about a minute. CLXP3D T153-T160 (the 3-stage bump on stage 1, XP's eight captured layouts,
rem T157 is 3DMark 2001's), then VXD3DMON for 3 s for the ring's state (a hang turns the ring off for the rest of the boot: run this
rem in its own boot, or after ALL.BAT). Install .793 (CHROME9.INF) and restart first. Send the folder TBUMP.
if not exist CLXP3D.EXE goto nofiles
if not exist VXD3DMON.EXE goto nofiles
if not exist VXREG.EXE goto nofiles
start /w VXREG.EXE
find "build: .793" VXREG.LOG >nul
if errorlevel 1 goto wrongbuild
if not exist TBUMP\nul md TBUMP
if exist CLXP3D1??.BIN del CLXP3D1??.BIN
echo CLXP3D: the bump cases T153-T160, under a minute.
start /w CLXP3D.EXE from 153 nocapture
copy CLXP3D.TXT TBUMP\CLXP3D.TXT >nul
del CLXP3D.TXT
if exist CLXP3D1??.BIN copy CLXP3D1??.BIN TBUMP >nul
if exist CLXP3D1??.BIN del CLXP3D1??.BIN
if exist VXD3DMON.TXT del VXD3DMON.TXT
start /w VXD3DMON.EXE 3
copy VXD3DMON.TXT TBUMP\BUMPMON.TXT >nul
del VXD3DMON.TXT
copy VXREG.LOG TBUMP\REG.LOG >nul
del VXREG.LOG
echo Done. Send the folder TBUMP.
goto end
:wrongbuild
echo The driver that is running is not .793 (see VXREG.LOG). Install CHROME9.INF from this package, restart, and run this again.
goto end
:nofiles
echo CLXP3D.EXE, VXD3DMON.EXE and VXREG.EXE must be in the current folder.
:end
pause
