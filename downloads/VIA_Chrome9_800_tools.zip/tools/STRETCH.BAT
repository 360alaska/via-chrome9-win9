@echo off
rem Driver .793: the engine stretch's picture alone, about a minute. VXNOSYNC STRETCH stretches a 256 x 256 back buffer into a window
rem (a windowed Present) at six sizes (two with a small window over them), once by the engine and once by the CPU, and compares the
rem two pictures pixel for pixel, with the driver's count of Blts and clip rectangles for each.
rem Leave the mouse and the windows alone while it runs (another window over it spoils the read-back). Desktop at 32-bit or 16-bit colour.
rem Install .793 (CHROME9.INF) and restart first. Send the folder TSTR.
if not exist VXNOSYNC.EXE goto nofiles
if not exist VXREG.EXE goto nofiles
start /w VXREG.EXE
find "build: .793" VXREG.LOG >nul
if errorlevel 1 goto wrongbuild
if not exist TSTR\nul md TSTR
if exist VXNOSYNC.LOG del VXNOSYNC.LOG
echo VXNOSYNC STRETCH: about two minutes; leave the machine alone.
start /w VXNOSYNC.EXE STRETCH
if exist VXNOSYNC.LOG copy VXNOSYNC.LOG TSTR\STRETCH.LOG >nul
if exist VXNOSYNC.LOG del VXNOSYNC.LOG
copy VXREG.LOG TSTR\REG.LOG >nul
del VXREG.LOG
echo Done. Send the folder TSTR.
goto end
:wrongbuild
echo The driver that is running is not .793 (see VXREG.LOG). Install CHROME9.INF from this package, restart, and run this again.
goto end
:nofiles
echo VXNOSYNC.EXE and VXREG.EXE must be in the current folder.
:end
pause
