@echo off
rem Driver .793: the targeted run (QUICK.BAT), about 10 minutes. ALL.BAT in this folder is the full run.
rem Every build: VXREG (the build), VXTLP (the pictures), VXNOSYNC, CLXP3D. This build also: nothing more.
rem Install .793 (CHROME9.INF) and restart first. Send the folder T793.
if not exist VXREG.EXE goto nofiles
if not exist VXTLP.EXE goto nofiles
if not exist CLXP3D.EXE goto nofiles
if not exist VXNOSYNC.EXE goto nofiles
if not exist ALLON.REG goto nofiles
if not exist %windir%\SYSTEM\D3D8.DLL goto nodx
start /w VXREG.EXE
find "build: .793" VXREG.LOG >nul
if errorlevel 1 goto wrongbuild
if not exist T793\nul md T793
if exist T793\STEPS.TXT del T793\STEPS.TXT
regedit /s ALLON.REG
copy VXREG.LOG T793\REG.LOG >nul
if exist VXT?_?.BMP del VXT?_?.BMP
if exist VXT??_?.BMP del VXT??_?.BMP
if exist VXTL7*.BMP del VXTL7*.BMP
if exist VXTL1?A.BMP del VXTL1?A.BMP
if exist VXTL1?B.BMP del VXTL1?B.BMP
if exist VXTLC_?.BMP del VXTLC_?.BMP
if exist VXTLF??.BMP del VXTLF??.BMP
if exist 6M*.BMP del 6M*.BMP
if exist 6P*.BMP del 6P*.BMP
if exist 6N*.BMP del 6N*.BMP
if exist 6Q*.BMP del 6Q*.BMP
if exist 6W*.BMP del 6W*.BMP
echo 0 VXVBL>> T793\STEPS.TXT
echo 0. VXVBL: a locked vertex buffer and the 16-bit lock, a few seconds.
if exist VXVBL.LOG del VXVBL.LOG
if exist VXVBL.EXE start /w VXVBL.EXE
if exist VXVBL.LOG copy VXVBL.LOG T793\VXVBL.LOG >nul
if exist VXVBL.LOG del VXVBL.LOG
echo 1 VXTLP>> T793\STEPS.TXT
echo 1. VXTLP: the picture checks, 2-3 minutes.
start /w VXTLP.EXE
copy VXTLP.LOG T793\VXTLP.LOG >nul
del VXTLP.LOG
if exist VXT?_?.BMP copy VXT?_?.BMP T793 >nul
if exist VXT?_?.BMP del VXT?_?.BMP
if exist VXT??_?.BMP copy VXT??_?.BMP T793 >nul
if exist VXT??_?.BMP del VXT??_?.BMP
if exist VXTL7*.BMP copy VXTL7*.BMP T793 >nul
if exist VXTL7*.BMP del VXTL7*.BMP
if exist VXTL1?A.BMP copy VXTL1?A.BMP T793 >nul
if exist VXTL1?A.BMP del VXTL1?A.BMP
if exist VXTL1?B.BMP copy VXTL1?B.BMP T793 >nul
if exist VXTL1?B.BMP del VXTL1?B.BMP
if exist VXTLC_?.BMP copy VXTLC_?.BMP T793 >nul
if exist VXTLC_?.BMP del VXTLC_?.BMP
if exist VXTLF??.BMP copy VXTLF??.BMP T793 >nul
if exist VXTLF??.BMP del VXTLF??.BMP
if exist 6M*.BMP copy 6M*.BMP T793 >nul
if exist 6M*.BMP del 6M*.BMP
if exist 6P*.BMP copy 6P*.BMP T793 >nul
if exist 6P*.BMP del 6P*.BMP
if exist 6N*.BMP copy 6N*.BMP T793 >nul
if exist 6N*.BMP del 6N*.BMP
if exist 6Q*.BMP copy 6Q*.BMP T793 >nul
if exist 6Q*.BMP del 6Q*.BMP
if exist 6W*.BMP copy 6W*.BMP T793 >nul
if exist 6W*.BMP del 6W*.BMP
echo 5 VXNOSYNC>> T793\STEPS.TXT
echo 5. VXNOSYNC: full screen, about a minute; the screen must stay white in passes 1-5.
if exist VXNOSYNC.LOG del VXNOSYNC.LOG
start /w VXNOSYNC.EXE
if exist VXNOSYNC.LOG copy VXNOSYNC.LOG T793\VXNOSY.LOG >nul
if exist VXNOSYNC.LOG del VXNOSYNC.LOG
echo 5 CLXP3D>> T793\STEPS.TXT
echo    CLXP3D: the cases from T153, under a minute.
if exist CLXP3D1??.BIN del CLXP3D1??.BIN
start /w CLXP3D.EXE from 153 nocapture
copy CLXP3D.TXT T793\CLXP.TXT >nul
del CLXP3D.TXT
if exist CLXP3D1??.BIN copy CLXP3D1??.BIN T793 >nul
if exist CLXP3D1??.BIN del CLXP3D1??.BIN
echo done>> T793\STEPS.TXT
echo Done. Send the folder T793.
goto end
:wrongbuild
echo The driver that is running is not .793 (see VXREG.LOG). Install CHROME9.INF from this package, restart, and run this again.
goto end
:nofiles
echo The test programs and .REG files of this package must be in the current folder.
goto end
:nodx
echo DirectX 8.1 or later is not installed (no D3D8.DLL in the SYSTEM folder): the Direct3D tests and HarborBench would be skipped.
echo Install DirectX 9.0c, restart, and run this again.
goto end
:end
pause
